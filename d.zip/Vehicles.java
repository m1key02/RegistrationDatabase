package t;

class Vehicles {

	String make;
	int mileage;
	String fueltype;
	String nct;
	int year;

	public Vehicles(String make1, int mileage1, String fueltype1, String nct1, int year1) {
		make = make1;
		mileage = mileage1;
		fueltype = fueltype1;
		nct = nct1;
		year = year1;
	}

	public String readMake() {
		return make;
	}

	public int readMileage() {
		return mileage;
	}

	public String readFuelType() {
		return fueltype;
	}

	public String readNct() {
		return nct;
	}

	public int readYear() {
		return year;
	}

	public int readSeats() {
		return 0;
	}
	
}
