package t;

import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class RegistrationFrame extends JFrame implements ActionListener {
	private JLabel heading = new JLabel("  Vehicle Registration  ");
	private JLabel makeLabel = new JLabel("Make ");
	private JTextField makeTextField = new JTextField("", 8);
	private JLabel mileageLabel = new JLabel("Mileage ");
	private JTextField mileageTextField = new JTextField("", 8);
	private JLabel fueltypeLabel = new JLabel("Fuel Type ");
	private JTextField fueltypeTextField = new JTextField("", 8);
	private JLabel seatsLabel = new JLabel("Seats ");
	private JTextField seatsTextField = new JTextField("", 8);
	private JLabel yearLabel = new JLabel("Year ");
	private JTextField nctTextField = new JTextField("No ", 8);
	private JLabel nctLabel = new JLabel("NCT Checked ");
	private JCheckBox nctCheckBox = new JCheckBox("NCT Checked ", false);
	private JButton confirmButton = new JButton("Confirm");
	private JButton markYearButton = new JButton("Mark year ");
	private JTextField yearTextField = new JTextField("", 8);
	private JButton databaseAccess = new JButton("Database");
	String[] list = { "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010",
			"2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022" };
	private JComboBox comboBoxYear = new JComboBox(list);
	private JPanel panelOne = new JPanel();
	private JPanel panelTwo = new JPanel();
	private ArrayList<Vehicles> vehicleArray = new ArrayList();
	private JRadioButton buttonForCar = new JRadioButton("Car");
	private JRadioButton buttonForMotorcycle = new JRadioButton("Motorcycle");
	Display display;

	public RegistrationFrame(String s) {
		super(s);
		Container content = getContentPane();
		content.setLayout(new FlowLayout());
		Font f = new Font("TimesRoman", Font.BOLD, 20);
		Font f2 = new Font("TimesRoman", Font.BOLD, 18);
		panelOne.setLayout(new GridLayout(7, 2));
		panelTwo.setLayout(new GridLayout(6, 2));
		heading.setFont(f);
		makeLabel.setFont(f2);
		content.add(heading);
		panelOne.add(makeLabel);
		panelOne.add(makeTextField);
		panelOne.add(mileageLabel);
		panelOne.add(mileageTextField);
		panelOne.add(fueltypeLabel);
		panelOne.add(fueltypeTextField);
		panelOne.add(seatsLabel);
		panelOne.add(seatsTextField);
		panelOne.add(nctLabel);
		panelOne.add(nctTextField);
		panelOne.add(yearLabel);
		yearTextField.setEditable(false);
		nctTextField.setEditable(false);
		panelOne.add(yearTextField);
		panelTwo.add(databaseAccess);
		panelTwo.add(confirmButton);
		panelTwo.add(markYearButton);
		panelTwo.add(comboBoxYear);
		panelTwo.add(buttonForCar);
		panelTwo.add(buttonForMotorcycle);

		content.add(panelOne);
		content.add(nctCheckBox);
		content.add(panelTwo);
		confirmButton.addActionListener(this);
		markYearButton.addActionListener(this);
		nctCheckBox.addActionListener(this);
		buttonForCar.addActionListener(this);
		buttonForMotorcycle.addActionListener(this);
		databaseAccess.addActionListener(this);
		buttonForCar.setSelected(true);
		ButtonGroup group = new ButtonGroup();
		group.add(buttonForCar);
		group.add(buttonForMotorcycle);

		AddElements();
		Refresh();
		setSize(310, 420);
		display = new Display(vehicleArray, this);
		setVisible(true);
	}

	public void Refresh() {
	}

	public void AddElements() {
	}

	public void actionPerformed(ActionEvent e) {

		Object target = e.getSource();

		if (target == confirmButton) {
			Vehicles veh = null;
			
			int seatsint = 0;
			int mileageint = 0;
			int yearint = 0;

			String make = makeTextField.getText();
			String mileage = mileageTextField.getText();
			String fueltype = fueltypeTextField.getText();
			String seats = seatsTextField.getText();
			String nct = nctTextField.getText();
			String year = yearTextField.getText();
			try {
				 seatsint = Integer.parseInt(seats.strip());
				 mileageint = Integer.parseInt(mileage.strip());
				 yearint = Integer.parseInt(year.strip());
			} catch (NumberFormatException y) {
				y.printStackTrace();
				JOptionPane.showMessageDialog(null, "Use Numbers in Seats, Mileage and Year Please.", "Error",
						JOptionPane.ERROR_MESSAGE);
			}

			if (buttonForCar.isSelected()) {
				veh = new Cars(make, mileageint, fueltype, seatsint, nct, yearint);
			} else if (buttonForMotorcycle.isSelected()) {
				veh = new Motorcycle(make, mileageint, fueltype, nct, yearint);
			}
			vehicleArray.add(veh);
		}

		if (target == nctCheckBox) {
			if (nctCheckBox.isSelected()) {
				nctTextField.setText("Yes");
			} else {
				nctTextField.setText("No");
			}
		}
		
		if (target == databaseAccess) {
			display.setDisplay(true);
		}

		if (target == buttonForMotorcycle) {
			if (buttonForMotorcycle.isSelected()) {
				seatsTextField.setEditable(false);
				seatsTextField.setText("2");
			}
		}

		if (target == buttonForCar) {
			if (buttonForCar.isSelected()) {
				seatsTextField.setEditable(true);
				seatsTextField.setText("");
			}
		}

		if (target == markYearButton) {
			String amt = (String) comboBoxYear.getSelectedItem();
			yearTextField.setText(amt);
		}

	}

}