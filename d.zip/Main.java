package t;

import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		LoginGUI login = new LoginGUI();
	}
}