package t;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Display extends JFrame implements ActionListener {
	JButton next;
	JButton prev;
	JButton registration;
	JTextArea area;
	ArrayList<Vehicles> list;
	int index = 0;
	Frame frame;
	Frame veh;

	public Display(ArrayList<Vehicles> l, Frame v) {
		veh = v;
		list = l;

		frame = new JFrame("Display");
		frame.setTitle("Display");
		frame.setSize(250, 250);

		JPanel mainPanen = new JPanel();
		mainPanen.setLayout(new BorderLayout());
		area = new JTextArea();
		mainPanen.add(BorderLayout.CENTER, area);
		area.setEditable(false);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		next = new JButton("Next");
		prev = new JButton("prev");
		registration = new JButton("Registration");
		buttonPanel.add(next);
		buttonPanel.add(prev);
		mainPanen.add(BorderLayout.NORTH, registration);
		mainPanen.add(BorderLayout.SOUTH, buttonPanel);

		next.addActionListener(this);
		prev.addActionListener(this);
		registration.addActionListener(this);

		frame.add(mainPanen);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();

		if (o == next) {
			index++;
			if (index >= list.size())
				index = list.size() - 1;
			setDisplayText();
		} else if (o == prev) {
			index--;
			if (index < 0)
				index = 0;
			setDisplayText();
		} else if (o == registration) {
			setDisplay(false);
		}
	}

	public void setDisplay(boolean show) {
		if (show) {
			veh.setVisible(false);
			frame.setVisible(true);
			setDisplayText();
		} else {
			frame.setVisible(false);
			veh.setVisible(true);
		}
	}

	private void setDisplayText() {
		if (list == null || list.size() == 0) {
			area.setText("No vehicles added");
			return;
		}
		String s;
		s = "  Make: " + list.get(index).readMake() + "\n" + "  Mileage: " + list.get(index).readMileage() + "\n"
				+ "  FuelType: " + list.get(index).readFuelType() + "\n" + "  Seats: " + list.get(index).readSeats() + "\n"
				+ "  Nct: " + list.get(index).readNct() + "\n" + "  Year: " + list.get(index).readYear() + "\n";
		area.setText(s);
	}
}