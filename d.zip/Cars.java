package t;

public class Cars extends Vehicles { 
	
	private int seats;
	
	public Cars(String make, int mileage, String fueltype,int numberofseats, String nct, int year) {
		super(make, mileage, fueltype, nct, year);
		seats = numberofseats;
	}
	@Override
	public int readSeats() {
		return seats;
	}
}