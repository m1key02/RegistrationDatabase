package t;

public class Motorcycle extends Vehicles {
	
	public Motorcycle(String make, int mileageint, String fueltype, String nct, int yearint) {
		super(make, mileageint, fueltype, nct, yearint);
	}
	@Override
	public int readSeats() {
		return 2;
	}
	
}
