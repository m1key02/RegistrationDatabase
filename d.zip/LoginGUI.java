package t;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginGUI extends JFrame implements ActionListener {
    Frame frame;
    JPanel mainPanel;
    JTextField loginText, passText;
    JLabel loginLabel, passLabel;
    JButton buttonOK, buttonCancel;

    public LoginGUI() {
        frame = new JFrame("Login");
        frame.setTitle("Login");

        loginLabel = new JLabel("Login");
        loginText = new JTextField(14);
        passLabel = new JLabel("Password");
        passText = new JTextField(14);
        buttonOK = new JButton("OK");
        buttonCancel = new JButton("Cancel");

        buttonOK.addActionListener(this);
        buttonCancel.addActionListener(this);

        mainPanel = new JPanel();
        GridLayout group = new GridLayout(3, 1);
        mainPanel.setLayout(group);

        JPanel loginLayout = new JPanel();
        loginLayout.setLayout(new FlowLayout(FlowLayout.RIGHT));
        mainPanel.add(loginLayout);

        JPanel passLayout = new JPanel();
        passLayout.setLayout(new FlowLayout(FlowLayout.RIGHT));
        mainPanel.add(passLayout);

        JPanel buttonLayout = new JPanel();
        buttonLayout.setLayout(new FlowLayout());
        mainPanel.add(buttonLayout);

        loginLayout.add(loginLabel);
        loginLayout.add(loginText);
        passLayout.add(passLabel);
        passLayout.add(passText);
        buttonLayout.add(buttonOK);
        buttonLayout.add(buttonCancel);

        frame.setSize(250, 140);
        frame.add(mainPanel);
        frame.setResizable(false);
        frame.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();

        if (o == buttonOK) {
            passwordCheck();
        } else if (o == buttonCancel) {
            System.exit(0);

        }
    }

    private void cancel() {
        System.exit(0);
    }

    private void passwordCheck() {
        String login = loginText.getText();
        String pass = passText.getText();

        if (login.equals("login") && pass.equals("pass")) {
            frame.dispose();
            student();
        } else {
            JOptionPane.showMessageDialog(null, "Wrong password!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void student() {
        new RegistrationFrame("Vehicle Registry");
    }

}
